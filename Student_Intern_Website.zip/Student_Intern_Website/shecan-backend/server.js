const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

app.use(cors());

// User data API
app.get("/api/user", (req, res) => {
  res.json({
    name: "Megha Choudhary",
    referralCode: "meghachoudhary2025",
    amountRaised: 7500
  });
});

// Bonus: leaderboard API
app.get("/api/leaderboard", (req, res) => {
  res.json([
    { name: "Megha Choudhary", amount: 7500 },
    { name: "Anjali Sharma", amount: 6200 },
    { name: "Ravi Kumar", amount: 5900 }
  ]);
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});
